/*
# Create LEARN WITH FLOW learning platform tables

1. New Tables
- `courses` — stores course metadata (title, description, category, thumbnail)
- `course_videos` — stores YouTube video URLs linked to each course, ordered by position
- `course_quizzes` — stores quiz questions with multiple-choice options and correct answers
- `certificates` — stores auto-generated certificates issued upon quiz completion

2. Security
- Single-tenant app (no sign-in). All tables use `TO anon, authenticated` policies so the anon-key client can read/write shared public data.
- RLS enabled on every table.

3. Notes
- `course_videos.position` and `course_quizzes.position` control ordering within a course.
- `course_quizzes.options` is a JSONB array of strings (multiple choice options).
- `course_quizzes.correct_answer` is an integer index into the options array.
- `certificates.score` is the percentage score achieved on the quiz.
*/

CREATE TABLE IF NOT EXISTS courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  category text NOT NULL DEFAULT 'General',
  thumbnail_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE courses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_courses" ON courses;
CREATE POLICY "anon_select_courses" ON courses FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_courses" ON courses;
CREATE POLICY "anon_insert_courses" ON courses FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_courses" ON courses;
CREATE POLICY "anon_update_courses" ON courses FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_courses" ON courses;
CREATE POLICY "anon_delete_courses" ON courses FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS course_videos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  youtube_url text NOT NULL,
  title text NOT NULL DEFAULT '',
  position integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE course_videos ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_videos" ON course_videos;
CREATE POLICY "anon_select_videos" ON course_videos FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_videos" ON course_videos;
CREATE POLICY "anon_insert_videos" ON course_videos FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_videos" ON course_videos;
CREATE POLICY "anon_update_videos" ON course_videos FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_videos" ON course_videos;
CREATE POLICY "anon_delete_videos" ON course_videos FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_course_videos_course_id ON course_videos(course_id);
CREATE INDEX IF NOT EXISTS idx_course_videos_position ON course_videos(course_id, position);

CREATE TABLE IF NOT EXISTS course_quizzes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  question text NOT NULL,
  options jsonb NOT NULL DEFAULT '[]'::jsonb,
  correct_answer integer NOT NULL DEFAULT 0,
  position integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE course_quizzes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_quizzes" ON course_quizzes;
CREATE POLICY "anon_select_quizzes" ON course_quizzes FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_quizzes" ON course_quizzes;
CREATE POLICY "anon_insert_quizzes" ON course_quizzes FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_quizzes" ON course_quizzes;
CREATE POLICY "anon_update_quizzes" ON course_quizzes FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_quizzes" ON course_quizzes;
CREATE POLICY "anon_delete_quizzes" ON course_quizzes FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_course_quizzes_course_id ON course_quizzes(course_id);
CREATE INDEX IF NOT EXISTS idx_course_quizzes_position ON course_quizzes(course_id, position);

CREATE TABLE IF NOT EXISTS certificates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  course_title text NOT NULL,
  student_name text NOT NULL,
  score integer NOT NULL,
  issued_at timestamptz DEFAULT now()
);

ALTER TABLE certificates ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_certificates" ON certificates;
CREATE POLICY "anon_select_certificates" ON certificates FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_certificates" ON certificates;
CREATE POLICY "anon_insert_certificates" ON certificates FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_certificates" ON certificates;
CREATE POLICY "anon_delete_certificates" ON certificates FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_certificates_course_id ON certificates(course_id);
