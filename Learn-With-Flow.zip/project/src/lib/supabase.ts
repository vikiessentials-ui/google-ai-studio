import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Course = {
  id: string;
  title: string;
  description: string;
  category: string;
  thumbnail_url: string | null;
  created_at: string;
};

export type CourseVideo = {
  id: string;
  course_id: string;
  youtube_url: string;
  title: string;
  position: number;
  created_at: string;
};

export type CourseQuiz = {
  id: string;
  course_id: string;
  question: string;
  options: string[];
  correct_answer: number;
  position: number;
  created_at: string;
};

export type Certificate = {
  id: string;
  course_id: string;
  course_title: string;
  student_name: string;
  score: number;
  issued_at: string;
};
