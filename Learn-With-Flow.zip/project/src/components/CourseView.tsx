import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Play,
  Video,
  HelpCircle,
  Check,
  X,
  Award,
  ChevronRight,
  Loader2,
  BookOpen,
  Lock,
} from 'lucide-react';
import {
  supabase,
  type Course,
  type CourseVideo,
  type CourseQuiz,
  type Certificate,
} from '@/lib/supabase';
import { extractYouTubeId, getYouTubeEmbedUrl } from '@/lib/youtube';
import CertificateView from './Certificate';

type CourseViewProps = {
  course: Course;
  onBack: () => void;
};

export default function CourseView({ course, onBack }: CourseViewProps) {
  const [videos, setVideos] = useState<CourseVideo[]>([]);
  const [quizzes, setQuizzes] = useState<CourseQuiz[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeVideoIdx, setActiveVideoIdx] = useState(0);
  const [showQuiz, setShowQuiz] = useState(false);

  // Quiz state
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [passed, setPassed] = useState(false);
  const [studentName, setStudentName] = useState('');
  const [certificate, setCertificate] = useState<Certificate | null>(null);
  const [showNameInput, setShowNameInput] = useState(false);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    loadCourseData();
  }, [course.id]);

  async function loadCourseData() {
    setLoading(true);
    const [{ data: videoData }, { data: quizData }] = await Promise.all([
      supabase
        .from('course_videos')
        .select('*')
        .eq('course_id', course.id)
        .order('position', { ascending: true }),
      supabase
        .from('course_quizzes')
        .select('*')
        .eq('course_id', course.id)
        .order('position', { ascending: true }),
    ]);

    setVideos(videoData ?? []);
    setQuizzes(quizData ?? []);
    setLoading(false);
  }

  function handleAnswerSelect(optionIndex: number) {
    if (quizSubmitted) return;
    setSelectedAnswer(optionIndex);
  }

  function handleNextQuestion() {
    if (selectedAnswer === null) return;
    const newAnswers = [...answers, selectedAnswer];
    setAnswers(newAnswers);
    setSelectedAnswer(null);

    if (currentQuestion < quizzes.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      submitQuiz(newAnswers);
    }
  }

  function submitQuiz(finalAnswers: number[]) {
    let correct = 0;
    quizzes.forEach((quiz, idx) => {
      if (finalAnswers[idx] === quiz.correct_answer) correct++;
    });
    const finalScore = Math.round((correct / quizzes.length) * 100);
    setScore(finalScore);
    setPassed(finalScore >= 70);
    setQuizSubmitted(true);
    if (finalScore >= 70) {
      setShowNameInput(true);
    }
  }

  function resetQuiz() {
    setCurrentQuestion(0);
    setAnswers([]);
    setSelectedAnswer(null);
    setQuizSubmitted(false);
    setScore(0);
    setPassed(false);
    setCertificate(null);
    setShowNameInput(false);
    setStudentName('');
  }

  async function generateCertificate() {
    if (!studentName.trim()) return;
    setGenerating(true);

    const { data, error } = await supabase
      .from('certificates')
      .insert({
        course_id: course.id,
        course_title: course.title,
        student_name: studentName.trim(),
        score,
      })
      .select()
      .single();

    if (error) {
      setGenerating(false);
      return;
    }

    setCertificate(data as Certificate);
    setShowNameInput(false);
    setGenerating(false);
  }

  const activeVideo = videos[activeVideoIdx];
  const activeVideoYtId = activeVideo ? extractYouTubeId(activeVideo.youtube_url) : null;
  const allVideosWatched = activeVideoIdx >= videos.length - 1;

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary-500 animate-spin" />
      </div>
    );
  }

  // Certificate view
  if (certificate) {
    return (
      <div className="min-h-screen bg-slate-900 py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/20 text-green-300 text-sm font-medium mb-4 animate-fade-in">
              <Check className="w-4 h-4" />
              Congratulations! You passed with {score}%
            </div>
            <h1 className="font-display text-3xl font-bold text-white mb-2">
              Your Certificate is Ready
            </h1>
            <p className="text-slate-400">Well done on completing this course</p>
          </div>

          <div className="animate-scale-in">
            <CertificateView certificate={certificate} />
          </div>

          <div className="flex items-center justify-center gap-4 mt-8">
            <button
              onClick={onBack}
              className="px-6 py-3 bg-white/10 text-white rounded-xl font-semibold hover:bg-white/20 transition-all"
            >
              Back to Courses
            </button>
            <button
              onClick={resetQuiz}
              className="px-6 py-3 bg-primary-600 text-white rounded-xl font-semibold hover:bg-primary-700 transition-all shadow-lg shadow-primary-500/30"
            >
              Retake Quiz
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Quiz results view
  if (quizSubmitted && !showNameInput) {
    return (
      <div className="min-h-screen bg-slate-50 py-12 px-4">
        <div className="max-w-2xl mx-auto">
          <button
            onClick={() => {
              setQuizSubmitted(false);
              setShowQuiz(false);
            }}
            className="flex items-center gap-2 text-slate-500 hover:text-slate-700 mb-6 font-medium"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Course
          </button>

          <div className="bg-white rounded-2xl border border-slate-100 shadow-xl p-8 text-center animate-scale-in">
            {passed ? (
              <>
                <div className="w-20 h-20 mx-auto rounded-full bg-green-50 flex items-center justify-center mb-4">
                  <Check className="w-10 h-10 text-green-500" />
                </div>
                <h2 className="font-display text-3xl font-bold text-slate-900 mb-2">
                  You Passed!
                </h2>
                <p className="text-slate-500 mb-6">
                  You scored {score}% on the quiz. Enter your name to generate your certificate.
                </p>
              </>
            ) : (
              <>
                <div className="w-20 h-20 mx-auto rounded-full bg-red-50 flex items-center justify-center mb-4">
                  <X className="w-10 h-10 text-red-400" />
                </div>
                <h2 className="font-display text-3xl font-bold text-slate-900 mb-2">
                  Not Quite There Yet
                </h2>
                <p className="text-slate-500 mb-6">
                  You scored {score}%. You need 70% or higher to pass and earn your certificate.
                  Review the videos and try again!
                </p>
              </>
            )}

            {/* Score breakdown */}
            <div className="flex items-center justify-center gap-6 mb-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-slate-900">{score}%</div>
                <div className="text-xs text-slate-500 font-medium uppercase tracking-wide">
                  Score
                </div>
              </div>
              <div className="w-px h-12 bg-slate-200" />
              <div className="text-center">
                <div className="text-3xl font-bold text-slate-900">
                  {answers.filter((a, i) => a === quizzes[i]?.correct_answer).length}/{quizzes.length}
                </div>
                <div className="text-xs text-slate-500 font-medium uppercase tracking-wide">
                  Correct
                </div>
              </div>
            </div>

            {passed ? (
              <div className="space-y-4">
                <input
                  type="text"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="Enter your full name for the certificate"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-primary-400 focus:ring-2 focus:ring-primary-100 outline-none transition-all text-slate-900 text-center font-medium"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && studentName.trim()) generateCertificate();
                  }}
                />
                <button
                  onClick={generateCertificate}
                  disabled={!studentName.trim() || generating}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-primary-600 text-white rounded-xl font-semibold hover:bg-primary-700 disabled:opacity-50 transition-all shadow-lg shadow-primary-500/30"
                >
                  {generating ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Award className="w-5 h-5" />
                      Generate Certificate
                    </>
                  )}
                </button>
              </div>
            ) : (
              <button
                onClick={resetQuiz}
                className="px-6 py-3 bg-primary-600 text-white rounded-xl font-semibold hover:bg-primary-700 transition-all shadow-lg shadow-primary-500/30"
              >
                Retake Quiz
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Quiz taking view
  if (showQuiz && quizzes.length > 0 && !quizSubmitted) {
    const quiz = quizzes[currentQuestion];
    const progress = ((currentQuestion + 1) / quizzes.length) * 100;

    return (
      <div className="min-h-screen bg-slate-50 py-8 px-4">
        <div className="max-w-2xl mx-auto">
          <button
            onClick={() => setShowQuiz(false)}
            className="flex items-center gap-2 text-slate-500 hover:text-slate-700 mb-6 font-medium"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Course
          </button>

          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-8 animate-fade-in">
            {/* Progress */}
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-slate-700">
                Question {currentQuestion + 1} of {quizzes.length}
              </span>
              <span className="text-sm text-slate-500">{Math.round(progress)}% Complete</span>
            </div>
            <div className="h-2 bg-slate-100 rounded-full overflow-hidden mb-6">
              <div
                className="h-full bg-primary-500 rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>

            <h2 className="text-xl font-semibold text-slate-900 mb-6">{quiz.question}</h2>

            <div className="space-y-3">
              {quiz.options.map((opt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAnswerSelect(idx)}
                  className={`w-full flex items-center gap-3 p-4 rounded-xl border-2 text-left transition-all ${
                    selectedAnswer === idx
                      ? 'border-primary-500 bg-primary-50'
                      : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <div
                    className={`w-7 h-7 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                      selectedAnswer === idx
                        ? 'border-primary-500 bg-primary-500'
                        : 'border-slate-300'
                    }`}
                  >
                    {selectedAnswer === idx && <Check className="w-4 h-4 text-white" />}
                  </div>
                  <span className={`text-sm font-medium ${selectedAnswer === idx ? 'text-primary-900' : 'text-slate-700'}`}>
                    {opt}
                  </span>
                </button>
              ))}
            </div>

            <button
              onClick={handleNextQuestion}
              disabled={selectedAnswer === null}
              className="w-full mt-6 flex items-center justify-center gap-2 px-6 py-3 bg-primary-600 text-white rounded-xl font-semibold hover:bg-primary-700 disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-lg shadow-primary-500/20"
            >
              {currentQuestion < quizzes.length - 1 ? (
                <>
                  Next Question
                  <ChevronRight className="w-5 h-5" />
                </>
              ) : (
                'Submit Quiz'
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Main course view
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Top bar */}
      <div className="sticky top-16 z-40 bg-white border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-slate-500 hover:text-slate-700 font-medium text-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            All Courses
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Course header */}
        <div className="mb-6">
          <span className="inline-block px-3 py-1 rounded-full bg-primary-50 text-primary-700 text-xs font-semibold mb-2">
            {course.category}
          </span>
          <h1 className="font-display text-3xl font-bold text-slate-900">{course.title}</h1>
          {course.description && (
            <p className="text-slate-500 mt-2 max-w-2xl">{course.description}</p>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Video player + list */}
          <div className="lg:col-span-2 space-y-4">
            {/* Active video */}
            {activeVideo && activeVideoYtId ? (
              <div className="bg-black rounded-2xl overflow-hidden shadow-xl aspect-video animate-fade-in">
                <iframe
                  key={activeVideo.id}
                  src={getYouTubeEmbedUrl(activeVideoYtId)}
                  title={activeVideo.title || `Video ${activeVideoIdx + 1}`}
                  className="w-full h-full"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-12 text-center">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-slate-100 flex items-center justify-center mb-4">
                  <Video className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-900 mb-1">No videos in this course</h3>
                <p className="text-sm text-slate-500">Add video lessons to get started.</p>
              </div>
            )}

            {/* Video playlist */}
            {videos.length > 0 && (
              <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-100">
                  <h3 className="font-semibold text-slate-900 text-sm flex items-center gap-2">
                    <Play className="w-4 h-4 text-primary-500" />
                    Course Content
                    <span className="text-slate-400 font-normal">({videos.length} videos)</span>
                  </h3>
                </div>
                <div className="divide-y divide-slate-50 max-h-80 overflow-y-auto scrollbar-thin">
                  {videos.map((video, idx) => {
                    const ytId = extractYouTubeId(video.youtube_url);
                    const isActive = idx === activeVideoIdx;
                    return (
                      <button
                        key={video.id}
                        onClick={() => setActiveVideoIdx(idx)}
                        className={`w-full flex items-center gap-3 p-3 text-left transition-colors ${
                          isActive ? 'bg-primary-50' : 'hover:bg-slate-50'
                        }`}
                      >
                        <span
                          className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                            isActive
                              ? 'bg-primary-600 text-white'
                              : 'bg-slate-100 text-slate-500'
                          }`}
                        >
                          {idx + 1}
                        </span>
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm font-medium truncate ${isActive ? 'text-primary-900' : 'text-slate-700'}`}>
                            {video.title || `Video ${idx + 1}`}
                          </p>
                          {ytId && (
                            <p className="text-xs text-slate-400 truncate">YouTube video</p>
                          )}
                        </div>
                        {isActive && <Play className="w-4 h-4 text-primary-500 fill-primary-500 flex-shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar: Quiz + Info */}
          <div className="space-y-4">
            {/* Quiz card */}
            {quizzes.length > 0 ? (
              <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-accent-50 flex items-center justify-center">
                    <HelpCircle className="w-5 h-5 text-accent-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900">Course Quiz</h3>
                    <p className="text-xs text-slate-500">{quizzes.length} questions</p>
                  </div>
                </div>
                <p className="text-sm text-slate-500 mb-4">
                  Test your knowledge and earn a certificate. Score 70% or higher to pass.
                </p>
                <button
                  onClick={() => {
                    setShowQuiz(true);
                    resetQuiz();
                  }}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-accent-500 text-white rounded-xl font-semibold hover:bg-accent-600 transition-all shadow-md shadow-accent-500/20"
                >
                  <HelpCircle className="w-4 h-4" />
                  Start Quiz
                </button>
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5 text-center">
                <div className="w-12 h-12 mx-auto rounded-xl bg-slate-100 flex items-center justify-center mb-3">
                  <Lock className="w-6 h-6 text-slate-400" />
                </div>
                <h3 className="font-semibold text-slate-900 text-sm">No Quiz Available</h3>
                <p className="text-xs text-slate-500 mt-1">
                  This course doesn't have a quiz yet. No certificate can be earned.
                </p>
              </div>
            )}

            {/* Certificate info */}
            {quizzes.length > 0 && (
              <div className="bg-gradient-to-br from-primary-50 to-accent-50 rounded-2xl border border-primary-100 p-5">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-sm">
                    <Award className="w-5 h-5 text-primary-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900">Certificate</h3>
                    <p className="text-xs text-slate-500">Auto-generated on completion</p>
                  </div>
                </div>
                <p className="text-sm text-slate-600">
                  Pass the quiz to earn a professional certificate signed by Muhammad Talha,
                  Founder &amp; CEO of LEARN WITH FLOW.
                </p>
              </div>
            )}

            {/* Course info */}
            <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
              <h3 className="font-semibold text-slate-900 text-sm mb-3 flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-primary-500" />
                Course Info
              </h3>
              <dl className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <dt className="text-slate-500">Videos</dt>
                  <dd className="font-medium text-slate-700">{videos.length}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-slate-500">Quiz Questions</dt>
                  <dd className="font-medium text-slate-700">{quizzes.length}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-slate-500">Category</dt>
                  <dd className="font-medium text-slate-700">{course.category}</dd>
                </div>
              </dl>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
