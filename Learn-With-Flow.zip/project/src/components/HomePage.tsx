import { useEffect, useState } from 'react';
import { Play, Clock, BookOpen, ArrowRight, Sparkles, Award, Video, HelpCircle } from 'lucide-react';
import { supabase, type Course, type CourseVideo, type CourseQuiz } from '@/lib/supabase';
import { getYouTubeThumbnail, extractYouTubeId } from '@/lib/youtube';

type CourseWithMeta = Course & {
  video_count: number;
  quiz_count: number;
  thumbnail: string | null;
};

type HomePageProps = {
  onOpenCourse: (course: Course) => void;
  onCreateCourse: () => void;
};

export default function HomePage({ onOpenCourse, onCreateCourse }: HomePageProps) {
  const [courses, setCourses] = useState<CourseWithMeta[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCourses();
  }, []);

  async function loadCourses() {
    setLoading(true);
    const { data: courseData } = await supabase
      .from('courses')
      .select('*')
      .order('created_at', { ascending: false });

    if (!courseData) {
      setLoading(false);
      return;
    }

    const enriched: CourseWithMeta[] = await Promise.all(
      courseData.map(async (course) => {
        const [{ data: videos }, { data: quizzes }] = await Promise.all([
          supabase.from('course_videos').select('youtube_url').eq('course_id', course.id),
          supabase.from('course_quizzes').select('id').eq('course_id', course.id),
        ]);

        const firstVideo = videos?.[0];
        const ytId = firstVideo ? extractYouTubeId(firstVideo.youtube_url) : null;
        const thumb = course.thumbnail_url || (ytId ? getYouTubeThumbnail(ytId) : null);

        return {
          ...course,
          video_count: videos?.length ?? 0,
          quiz_count: quizzes?.length ?? 0,
          thumbnail: thumb,
        };
      })
    );

    setCourses(enriched);
    setLoading(false);
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-50">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-50 via-white to-accent-50" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-primary-200/20 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-accent-200/20 rounded-full blur-3xl" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary-100 text-primary-700 text-sm font-medium mb-6 animate-fade-in-up">
              <Sparkles className="w-4 h-4" />
              Learn at your own pace
            </div>
            <h1 className="font-display text-5xl sm:text-6xl font-bold text-slate-900 leading-tight animate-fade-in-up animate-delay-100">
              Master New Skills with
              <span className="block gradient-text">Expert-Led Courses</span>
            </h1>
            <p className="mt-6 text-lg text-slate-600 leading-relaxed animate-fade-in-up animate-delay-200">
              Watch curated YouTube video lessons, test your knowledge with interactive quizzes,
              and earn professional certificates upon completion.
            </p>
            <div className="mt-8 flex items-center justify-center gap-4 animate-fade-in-up animate-delay-300">
              <button
                onClick={onCreateCourse}
                className="px-6 py-3 bg-primary-600 text-white rounded-xl font-semibold hover:bg-primary-700 shadow-lg shadow-primary-500/30 hover:shadow-primary-500/40 transition-all hover:-translate-y-0.5"
              >
                Create a Course
              </button>
              <a
                href="#courses"
                className="px-6 py-3 bg-white text-slate-700 rounded-xl font-semibold border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-all"
              >
                Browse Courses
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 relative z-10">
        <div className="grid grid-cols-3 gap-4 bg-white rounded-2xl shadow-xl shadow-slate-200/50 border border-slate-100 p-6">
          <div className="flex items-center gap-3 justify-center">
            <div className="w-12 h-12 rounded-xl bg-primary-50 flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-primary-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">{courses.length}</div>
              <div className="text-xs text-slate-500 font-medium">Courses</div>
            </div>
          </div>
          <div className="flex items-center gap-3 justify-center border-x border-slate-100">
            <div className="w-12 h-12 rounded-xl bg-accent-50 flex items-center justify-center">
              <Video className="w-6 h-6 text-accent-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">
                {courses.reduce((sum, c) => sum + c.video_count, 0)}
              </div>
              <div className="text-xs text-slate-500 font-medium">Video Lessons</div>
            </div>
          </div>
          <div className="flex items-center gap-3 justify-center">
            <div className="w-12 h-12 rounded-xl bg-green-50 flex items-center justify-center">
              <HelpCircle className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">
                {courses.reduce((sum, c) => sum + c.quiz_count, 0)}
              </div>
              <div className="text-xs text-slate-500 font-medium">Quiz Questions</div>
            </div>
          </div>
        </div>
      </section>

      {/* Courses grid */}
      <section id="courses" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="font-display text-3xl font-bold text-slate-900">All Courses</h2>
            <p className="text-slate-500 mt-1">Explore and start learning today</p>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div
                key={i}
                className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm animate-pulse"
              >
                <div className="h-48 bg-slate-200" />
                <div className="p-5 space-y-3">
                  <div className="h-4 bg-slate-200 rounded w-3/4" />
                  <div className="h-3 bg-slate-100 rounded w-full" />
                  <div className="h-3 bg-slate-100 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : courses.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-20 h-20 mx-auto rounded-2xl bg-slate-100 flex items-center justify-center mb-4">
              <BookOpen className="w-10 h-10 text-slate-400" />
            </div>
            <h3 className="text-xl font-semibold text-slate-900 mb-2">No courses yet</h3>
            <p className="text-slate-500 mb-6">Get started by creating your first course.</p>
            <button
              onClick={onCreateCourse}
              className="inline-flex items-center gap-2 px-6 py-3 bg-primary-600 text-white rounded-xl font-semibold hover:bg-primary-700 transition-all shadow-lg shadow-primary-500/30"
            >
              Create Your First Course
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course, idx) => (
              <button
                key={course.id}
                onClick={() => onOpenCourse(course)}
                className="group text-left bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm hover:shadow-xl hover:shadow-slate-200/60 transition-all hover:-translate-y-1 animate-fade-in-up"
                style={{ animationDelay: `${idx * 0.05}s`, opacity: 0 }}
              >
                <div className="relative h-48 bg-gradient-to-br from-primary-100 to-primary-50 overflow-hidden">
                  {course.thumbnail ? (
                    <img
                      src={course.thumbnail}
                      alt={course.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <BookOpen className="w-12 h-12 text-primary-300" />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                    <span className="text-white text-sm font-medium flex items-center gap-1.5">
                      <Play className="w-4 h-4 fill-white" />
                      Start Learning
                    </span>
                  </div>
                  <span className="absolute top-3 left-3 px-3 py-1 rounded-full bg-white/90 backdrop-blur text-xs font-semibold text-slate-700">
                    {course.category}
                  </span>
                </div>

                <div className="p-5">
                  <h3 className="font-semibold text-lg text-slate-900 group-hover:text-primary-700 transition-colors line-clamp-1">
                    {course.title}
                  </h3>
                  <p className="text-sm text-slate-500 mt-1 line-clamp-2">
                    {course.description || 'No description provided'}
                  </p>

                  <div className="flex items-center gap-4 mt-4 pt-4 border-t border-slate-100">
                    <span className="flex items-center gap-1.5 text-xs font-medium text-slate-600">
                      <Video className="w-4 h-4 text-primary-500" />
                      {course.video_count} videos
                    </span>
                    <span className="flex items-center gap-1.5 text-xs font-medium text-slate-600">
                      <HelpCircle className="w-4 h-4 text-accent-500" />
                      {course.quiz_count} questions
                    </span>
                    {course.quiz_count > 0 && (
                      <span className="flex items-center gap-1.5 text-xs font-medium text-green-600 ml-auto">
                        <Award className="w-4 h-4" />
                        Certificate
                      </span>
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-100 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-600 to-primary-400 flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <span className="font-display font-bold text-slate-900">LEARN WITH FLOW</span>
            </div>
            <p className="text-sm text-slate-500">
              Founded by Muhammad Talha — Empowering learners worldwide
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
