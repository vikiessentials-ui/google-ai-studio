import { GraduationCap, Plus, Home } from 'lucide-react';

type HeaderProps = {
  onNavigateHome: () => void;
  onNavigateCreate: () => void;
  currentView: string;
};

export default function Header({ onNavigateHome, onNavigateCreate, currentView }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-lg border-b border-slate-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <button
            onClick={onNavigateHome}
            className="flex items-center gap-2.5 group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-600 to-primary-400 flex items-center justify-center shadow-lg shadow-primary-500/30 group-hover:shadow-primary-500/50 transition-shadow">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div className="text-left">
              <span className="font-display font-bold text-lg text-slate-900 leading-none block">
                LEARN WITH FLOW
              </span>
              <span className="text-[10px] font-medium text-slate-500 tracking-widest uppercase">
                Online Learning Platform
              </span>
            </div>
          </button>

          <nav className="flex items-center gap-2">
            <button
              onClick={onNavigateHome}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                currentView === 'home'
                  ? 'bg-primary-50 text-primary-700'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Home className="w-4 h-4" />
              <span className="hidden sm:inline">Courses</span>
            </button>
            <button
              onClick={onNavigateCreate}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                currentView === 'create'
                  ? 'bg-primary-50 text-primary-700'
                  : 'bg-primary-600 text-white hover:bg-primary-700 shadow-md shadow-primary-500/20'
              }`}
            >
              <Plus className="w-4 h-4" />
              <span>Create Course</span>
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
}
