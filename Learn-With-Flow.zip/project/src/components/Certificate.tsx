import { useRef } from 'react';
import { Award, Download } from 'lucide-react';
import type { Certificate } from '@/lib/supabase';

type CertificateProps = {
  certificate: Certificate;
  onDownload?: () => void;
};

export default function CertificateView({ certificate, onDownload }: CertificateProps) {
  const certRef = useRef<HTMLDivElement>(null);

  const issueDate = new Date(certificate.issued_at).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const certId = certificate.id.substring(0, 8).toUpperCase();

  return (
    <div className="flex flex-col items-center">
      <div
        ref={certRef}
        className="certificate-border relative w-full max-w-4xl aspect-[1.414/1] rounded-2xl shadow-2xl overflow-hidden"
        style={{
          backgroundImage: `
            linear-gradient(135deg, rgba(254,249,195,0.3) 0%, rgba(255,255,255,0.5) 50%, rgba(254,249,195,0.3) 100%)
          `,
        }}
      >
        {/* Decorative border */}
        <div className="absolute inset-3 border-2 border-accent-300/60 rounded-xl" />
        <div className="absolute inset-4 border border-accent-400/30 rounded-lg" />

        {/* Corner ornaments */}
        <div className="absolute top-6 left-6 w-16 h-16">
          <div className="absolute top-0 left-0 w-full h-0.5 bg-accent-500/40" />
          <div className="absolute top-0 left-0 w-0.5 h-full bg-accent-500/40" />
          <Award className="absolute top-3 left-3 w-6 h-6 text-accent-500/50" />
        </div>
        <div className="absolute top-6 right-6 w-16 h-16">
          <div className="absolute top-0 right-0 w-full h-0.5 bg-accent-500/40" />
          <div className="absolute top-0 right-0 w-0.5 h-full bg-accent-500/40" />
          <Award className="absolute top-3 right-3 w-6 h-6 text-accent-500/50" />
        </div>
        <div className="absolute bottom-6 left-6 w-16 h-16">
          <div className="absolute bottom-0 left-0 w-full h-0.5 bg-accent-500/40" />
          <div className="absolute bottom-0 left-0 w-0.5 h-full bg-accent-500/40" />
        </div>
        <div className="absolute bottom-6 right-6 w-16 h-16">
          <div className="absolute bottom-0 right-0 w-full h-0.5 bg-accent-500/40" />
          <div className="absolute bottom-0 right-0 w-0.5 h-full bg-accent-500/40" />
        </div>

        {/* Content */}
        <div className="relative h-full flex flex-col items-center justify-center px-12 text-center">
          {/* Logo / Brand */}
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary-600 to-primary-400 flex items-center justify-center shadow-lg">
              <Award className="w-7 h-7 text-white" />
            </div>
            <div className="text-left">
              <div className="font-display font-bold text-slate-800 text-lg leading-none">
                LEARN WITH FLOW
              </div>
              <div className="text-[8px] font-medium text-slate-500 tracking-widest uppercase mt-0.5">
                Online Learning Platform
              </div>
            </div>
          </div>

          {/* Title */}
          <h2 className="font-display text-4xl font-bold text-slate-800 tracking-wide">
            Certificate of Completion
          </h2>
          <div className="w-32 h-0.5 bg-accent-500/40 mt-3 mb-4" />

          {/* Recipient */}
          <p className="text-sm text-slate-500 font-medium uppercase tracking-widest">
            This certificate is proudly presented to
          </p>
          <h3 className="font-display text-3xl font-bold text-slate-900 mt-2 mb-1">
            {certificate.student_name}
          </h3>
          <div className="w-48 h-px bg-slate-300 my-2" />

          {/* Course */}
          <p className="text-sm text-slate-500 max-w-md mt-1">
            for successfully completing the course and demonstrating proficiency in
          </p>
          <p className="font-display text-xl font-semibold text-primary-700 mt-1">
            {certificate.course_title}
          </p>

          {/* Score badge */}
          <div className="mt-3 inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-green-50 border border-green-200">
            <span className="text-xs font-semibold text-green-700">
              Score: {certificate.score}%
            </span>
          </div>

          {/* Signatures */}
          <div className="absolute bottom-10 left-0 right-0 flex items-end justify-between px-16">
            <div className="text-center">
              <div className="font-display text-lg italic text-slate-700 mb-1" style={{ transform: 'rotate(-3deg)' }}>
                Muhammad Talha
              </div>
              <div className="w-32 h-px bg-slate-400" />
              <p className="text-[10px] font-semibold text-slate-600 mt-1.5 uppercase tracking-wide">
                Muhammad Talha
              </p>
              <p className="text-[9px] text-slate-500 mt-0.5">
                Founder &amp; CEO, LEARN WITH FLOW
              </p>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-16 h-16 rounded-full border-2 border-accent-400/40 flex items-center justify-center bg-accent-50/50">
                <Award className="w-8 h-8 text-accent-500/70" />
              </div>
              <p className="text-[9px] text-slate-500 mt-1">Official Seal</p>
            </div>

            <div className="text-center">
              <div className="font-mono text-sm text-slate-400 mb-1">{certId}</div>
              <div className="w-32 h-px bg-slate-400" />
              <p className="text-[10px] font-semibold text-slate-600 mt-1.5 uppercase tracking-wide">
                Date Issued
              </p>
              <p className="text-[10px] text-slate-500 mt-0.5">{issueDate}</p>
            </div>
          </div>
        </div>
      </div>

      {onDownload && (
        <button
          onClick={onDownload}
          className="mt-6 flex items-center gap-2 px-6 py-3 bg-primary-600 text-white rounded-xl font-semibold hover:bg-primary-700 shadow-lg shadow-primary-500/30 transition-all hover:-translate-y-0.5"
        >
          <Download className="w-5 h-5" />
          Download Certificate
        </button>
      )}
    </div>
  );
}
