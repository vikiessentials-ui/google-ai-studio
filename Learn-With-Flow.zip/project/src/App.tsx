import { useState } from 'react';
import Header from '@/components/Header';
import HomePage from '@/components/HomePage';
import CourseEditor from '@/components/CourseEditor';
import CourseView from '@/components/CourseView';
import type { Course } from '@/lib/supabase';

type View = 'home' | 'create' | 'course';

function App() {
  const [view, setView] = useState<View>('home');
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

  function navigateHome() {
    setView('home');
    setSelectedCourse(null);
  }

  function navigateCreate() {
    setView('create');
    setSelectedCourse(null);
  }

  function openCourse(course: Course) {
    setSelectedCourse(course);
    setView('course');
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Header
        onNavigateHome={navigateHome}
        onNavigateCreate={navigateCreate}
        currentView={view}
      />

      {view === 'home' && <HomePage onOpenCourse={openCourse} onCreateCourse={navigateCreate} />}

      {view === 'create' && <CourseEditor onSaved={navigateHome} onCancel={navigateHome} />}

      {view === 'course' && selectedCourse && (
        <CourseView course={selectedCourse} onBack={navigateHome} />
      )}
    </div>
  );
}

export default App;
